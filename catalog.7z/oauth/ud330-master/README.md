# ud330

This repository contains the code used in the Udacity course Full-Stack Foundations. This code is intended to be a supplement to the course material and runs in the vagrant environment provided in the course. Please report any errors in the code or feel free to make a pull request and I will get to the issue as soon as possible. 
