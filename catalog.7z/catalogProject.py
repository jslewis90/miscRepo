from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc, desc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Category, Item, User
app = Flask(__name__)

# Connect to Database and create database session
engine = create_engine('sqlite:///itemcatalog.db')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()

@app.route('/')
@app.route('/catalog')
def showCatalog():
    categories = session.query(Category).order_by(asc(Category.name))
    items = session.query(Item).order_by(desc(Item.id)).limit(9)
    return render_template('catalog.html', categories=categories, items=items)

@app.route('/catalog/<string:category_name>')
@app.route('/catalog/<string:category_name>/items')
def showCategory(category_name):
    categories = session.query(Category).order_by(asc(Category.name))
    category = session.query(Category).filter_by(name=category_name).one()
    items = session.query(Item).filter_by(cat_id=category.id)
    return render_template('category.html', categories=categories, category=category, items=items)

@app.route('/catalog/category/new', methods=['GET', 'POST'])
def newCategory():
    categories = session.query(Category).order_by(asc(Category.name))
    if request.method == 'POST':
        name = request.form['name']
        try:
            for category in categories:
                assert (category.name != name)
        except:
            flash("Error: Category name is not unique.")
            return render_template('newCategory.html', name=name)
        else:
            newCategory = Category(name=name)
            session.add(newCategory)
            session.commit()
            flash("New Category Successfully Created!")
            return redirect(url_for('showCatalog'))
    else:
        return render_template('newCategory.html')

@app.route('/catalog/<string:category_name>/edit', methods=['GET', 'POST'])
def editCategory(category_name):
    category = session.query(Category).filter_by(name=category_name).one()
    if request.method == 'POST':
        if request.form['name']:
            name = request.form['name']
        try:
            for category in categories:
                assert (category.name != name)
        except:
            flash("Error: Category name is not unique.")
            return render_template('editCategory.html', name=name, category=category)
    else:
        return render_template('editCategory.html', category=category)

@app.route('/catalog/<string:category_name>/delete', methods=['GET', 'POST'])
def deleteCategory(category_name):
    category = session.query(Category).filter_by(name=category_name).one()
    if request.method == 'POST':
        return category_name + 'deleted'
    else:
        return category.name

@app.route('/catalog/<string:category_name>/<int:item_id>')
def showItem(category_name, item_id):
    itemCategory = session.query(Category).filter_by(name=category_name).one()
    item = session.query(Item).filter_by(cat_id=itemCategory.id, id=item_id).one()
    return render_template('item.html', item=item, category=item.categories)

@app.route('/catalog/item/new', methods=['GET', 'POST'])
@app.route('/catalog/<string:category_name>/new', methods=['GET', 'POST'])
def newItem(category_name=''):
    categories = session.query(Category).order_by(asc(Category.name))
    if category_name != '':
        currentCategory = session.query(Category).filter_by(name=category_name).one()
    else:
        currentCategory = ''
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        picture = request.form['picture']
        cat_id = request.form['category']
        newItem = Item(title=title, description= description, picture=picture,
                        cat_id=cat_id)
        items = session.query(Item).order_by(asc(Item.title))

        try:
            for item in items:
                assert (item.title != title)
        except:
            flash("Error: Item name is not unique.")
            return render_template('newItem.html', currentCategory=currentCategory,
                                    categories=categories, title=title,
                                    description=description, picture=picture)
        else:
            session.add(newItem)
            session.commit()
            flash("New Item Successfully Created!")
            return redirect(url_for('showCatalog'))
    else:
        return render_template('newItem.html', currentCategory=currentCategory,
                                categories=categories)

@app.route('/catalog/<string:category_name>/<int:item_id>/edit', methods=['GET', 'POST'])
def editItem(category_name, item_id):
    categories = session.query(Category).order_by(asc(Category.name))
    itemCategory = session.query(Category).filter_by(name=category_name).one()
    item = session.query(Item).filter_by(cat_id=itemCategory.id, id=item_id).one()
    if request.method == 'POST':
        if request.form['title']:
            item.title = request.form['title']
        if request.form['description']:
            item.description = request.form['description']
        if request.form['picture']:
            item.picture = request.form['picture']
        if request.form['category']:
            item.cat_id = request.form['category']
        session.add(item)
        session.commit()
        flash("Item Successfully Edited!")
        return redirect(url_for('showCategory', category_name = item.categories.name))
    else:
        return render_template('editItem.html', categories=categories, item=item)

@app.route('/catalog/<string:category_name>/<int:item_id>/delete', methods=['GET', 'POST'])
def deleteItem(category_name, item_id):
    category = session.query(Category).filter_by(name=category_name).one()
    item = session.query(Item).filter_by(cat_id=category.id, id=item_id).one()
    if request.method == 'POST':
        session.delete(item)
        session.commit()
        flash("Item Successfully Deleted!")
        return redirect(url_for('showCategory', category_name = item.categories.name))
    else:
        return render_template('deleteItem.html', category=category, item=item)

@app.route('/catalog.json')
def showJSON():
    categories = session.query(Category).all()
    return jsonify(Category=[c.serialize for c in categories])

@app.route('/login')
def login():
    return render_template('login.html')

if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host = '0.0.0.0', port = 8000)
