from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database_setup import Base, Category, Item, User

engine = create_engine('sqlite:///itemcatalog.db')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()

######################
##    Categories    ##
######################
Category1 = Category(name='Electronics')
session.add(Category1)
session.commit()

Category2 = Category(name='Sports')
session.add(Category2)
session.commit()

######################
##       Items      ##
######################
Item1 = Item(cat_id=1, title='Lightning to USB Cable',
            description='Cable to sync / charge Apple mobile devices',
            picture='http://as-images.apple.com/is/image/AppleInc/aos/published/images/M/D8/MD818/MD818')
session.add(Item1)
session.commit()

Item2 = Item(cat_id=2, title='Basketball',
            description='Spherical striped orange ball used for a game of Basketball.',
            picture='https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Basketball.png/220px-Basketball.png')
session.add(Item2)
session.commit()

# Output statement
print "added items and categories!"
